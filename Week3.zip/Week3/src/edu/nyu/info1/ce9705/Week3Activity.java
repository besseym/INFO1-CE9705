package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Week3Activity extends Activity {
	
	private static final String TAG = "Week3Activity";
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Integer count = new Integer(10);
        
        final LinearLayout.LayoutParams countTextLayoutParams 
        	= new LinearLayout.LayoutParams(
        		ViewGroup.LayoutParams.WRAP_CONTENT,
        		ViewGroup.LayoutParams.WRAP_CONTENT,
        		0.0f
        );
        
        final LinearLayout mainLayout = (LinearLayout)findViewById(R.id.main_layout);
        
        final TextView countDownTextView = new TextView(this);
        countDownTextView.setLayoutParams(countTextLayoutParams);
        countDownTextView.setText(count.toString());
        countDownTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 50);
        
        final Handler handler = new Handler() {
			@Override
			public void handleMessage(Message message) {
				
				int count = message.arg1;
				if(count > 0){
					countDownTextView.setText(String.valueOf(message.arg1));
				}
				else {
					countDownTextView.setText(R.string.message_count_complete);
					mainLayout.setBackgroundColor(0xFF800000);
					
					Toast.makeText(Week3Activity.this, R.string.message_appreciation, Toast.LENGTH_LONG).show();
				}
				
			}
		};
        
        Button startButton = (Button) findViewById(R.id.button_start);
        startButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d(TAG, "start button clicked");
				
				v.setVisibility(View.GONE);
				
				mainLayout.addView(countDownTextView);
				
				final CountThread countThread = new CountThread(count, handler);
				countThread.start();
			}
        });
    }
}