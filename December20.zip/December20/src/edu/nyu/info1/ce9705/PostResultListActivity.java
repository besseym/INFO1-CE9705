/**
 * 
 */
package edu.nyu.info1.ce9705;

import java.util.List;

import android.app.DialogFragment;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import edu.nyu.info1.ce9705.facebook.Post;
import edu.nyu.info1.ce9705.facebook.User;
import edu.nyu.info1.ce9705.search.PostQueryResult;
import edu.nyu.info1.ce9705.search.PostResultAdapter;
import edu.nyu.info1.ce9705.search.QueryUserTask;
import edu.nyu.info1.ce9705.search.SearchPostTask;

/**
 * @author besseym
 *
 */
public class PostResultListActivity extends ListActivity {
	
	private PostQueryResult postQueryResult;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search_result_list);
		
		Bundle extras = getIntent().getExtras();
		this.postQueryResult = (PostQueryResult) extras.get(IntentExtra.POST_QUERY_RESULT_EXTRA);
		
		this.setListAdapter(new PostResultAdapter(this, this.postQueryResult.getPostList()));
	}
	
	@Override
	public void onListItemClick(ListView parent, View view, int position, long id){
		
		Integer userId = postQueryResult.getPostList().get(position).getFrom().getId();
		
		DialogFragment progressFragment = ProgressDialogFragment.newInstance();
		progressFragment.show(getFragmentManager(), "dialog");
		
		QueryUserTask queryUserTask = new QueryUserTask(this,progressFragment);
		queryUserTask.execute(userId);
		
//		Toast.makeText(this, postList.get(position).getFrom().getName(), Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * 
	 * @param user
	 */
	public void setUser(User user){
		
		Intent intent = new Intent(this, ViewUserActivity.class);
    	intent.putExtra(IntentExtra.USER_EXTRA, user);
    	startActivity(intent);
	}
	
	 /**
     * 
     */
    public void onQueryError(){
    	Toast.makeText(this, R.string.query_user_error, Toast.LENGTH_LONG).show();
    }
}
