package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import edu.nyu.info1.ce9705.search.PostQueryResult;
import edu.nyu.info1.ce9705.search.SearchPostTask;

public class December20Activity extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        final Button searchButton = (Button)findViewById(R.id.search_button);
        final EditText searchText = (EditText)findViewById(R.id.search_text);

        searchButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				Editable editable = searchText.getText();
				String query = editable.toString();
				
				if(query != null && !"".equals(query)){
				
					DialogFragment progressFragment = ProgressDialogFragment.newInstance();
					progressFragment.show(getFragmentManager(), "dialog");
					
					SearchPostTask searchUsersTask = new SearchPostTask(December20Activity.this, progressFragment);
					searchUsersTask.execute(query);
				}
			}
		});
    }
    
    /**
     * 
     * @param postList
     */
    public void setPostQueryResult(PostQueryResult postQueryResult) {
		
		Intent intent = new Intent(December20Activity.this, PostResultListActivity.class);
    	intent.putExtra(IntentExtra.POST_QUERY_RESULT_EXTRA, postQueryResult);
    	startActivity(intent);
    }
    
    /**
     * 
     */
    public void onQueryError(){
    	Toast.makeText(this, R.string.query_error, Toast.LENGTH_LONG).show();
    }
}