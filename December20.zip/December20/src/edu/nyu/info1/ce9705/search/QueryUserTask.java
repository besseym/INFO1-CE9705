/**
 * 
 */
package edu.nyu.info1.ce9705.search;

import org.json.JSONException;

import android.app.DialogFragment;
import android.os.AsyncTask;
import android.util.Log;
import edu.nyu.info1.ce9705.PostResultListActivity;
import edu.nyu.info1.ce9705.facebook.User;
import edu.nyu.info1.ce9705.json.facebook.FacebookJsonDao;

/**
 * @author besseym
 *
 */
public class QueryUserTask extends AsyncTask<Integer, Integer, User> {
	
	private Boolean taskError;
	
	private PostResultListActivity activity;
	private DialogFragment progressFragment;
	
	public QueryUserTask(PostResultListActivity activity, DialogFragment progressFragment){
		
		this.taskError = new Boolean(false);
		this.activity = activity;
		this.progressFragment = progressFragment;
	}

	/*
	 * (non-Javadoc)
	 * @see android.os.AsyncTask#doInBackground(Params[])
	 */
	@Override
	protected User doInBackground(Integer... idArray) {
		
		this.taskError = new Boolean(false);
		
		User user = null;
		
		if(idArray.length > 0){
		
			Integer id = idArray[0];
			if(id > 0){
				
				try {
					FacebookJsonDao facebookJsonDao = new FacebookJsonDao();
					user = facebookJsonDao.queryUser(id);
				} catch (Exception e) {
					this.taskError = new Boolean(true);
					Log.e(QueryUserTask.class.toString(), e.getMessage(), e);
				}
			}
		}
		
		return user;
	}
	
	/*
	 * (non-Javadoc)
	 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
	 */
	@Override
    protected void onPostExecute(User user){
		
		if(!this.taskError){
			activity.setUser(user);	
		}
		else {
			activity.onQueryError();
		}
		
		progressFragment.dismiss();
	}

}
