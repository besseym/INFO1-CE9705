/**
 * 
 */
package edu.nyu.info1.ce9705.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import edu.nyu.info1.ce9705.facebook.Post;

/**
 * @author besseym
 *
 */
public class PostQueryResult implements Serializable {
	
	private List<Post> postList;

	/**
	 * Constructor
	 */
	public PostQueryResult() {
		this.postList = new ArrayList<Post>();
	}

	/**
	 * @return the postList
	 */
	public List<Post> getPostList() {
		return postList;
	}

}
