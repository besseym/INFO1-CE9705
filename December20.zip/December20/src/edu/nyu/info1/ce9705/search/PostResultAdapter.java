/**
 * 
 */
package edu.nyu.info1.ce9705.search;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import edu.nyu.info1.ce9705.R;
import edu.nyu.info1.ce9705.facebook.Post;

/**
 * @author besseym
 *
 */
public class PostResultAdapter extends BaseAdapter {
	
	private LayoutInflater mInflater;
	private List<Post> postList;

	/**
	 * 
	 */
	public PostResultAdapter(Context context, List<Post> postList) {
		
		this.mInflater = LayoutInflater.from(context);
		this.postList = postList;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getCount()
	 */
	@Override
	public int getCount() {
		return postList.size();
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItem(int)
	 */
	@Override
	public Object getItem(int position) {
		return postList.get(position);
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getItemId(int)
	 */
	@Override
	public long getItemId(int position) {
		return position;
	}

	/* (non-Javadoc)
	 * @see android.widget.Adapter#getView(int, android.view.View, android.view.ViewGroup)
	 */
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		ViewHolder holder = null;
		
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.search_result, null);
			
			holder = new ViewHolder();
			holder.nameTextView = (TextView)convertView.findViewById(R.id.user_name);
			holder.messageTextView = (TextView)convertView.findViewById(R.id.message);
			convertView.setTag(holder);
		}
		else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		Post post = postList.get(position);
		
		holder.nameTextView.setText(post.getFrom().getName());
		holder.messageTextView.setText(post.getMessage());
		
		return convertView;
	}
	
	static class ViewHolder {
        TextView nameTextView;
        TextView messageTextView;
    }

}
