/**
 * 
 */
package edu.nyu.info1.ce9705.search;

import org.json.JSONException;

import android.app.DialogFragment;
import android.os.AsyncTask;
import android.util.Log;
import edu.nyu.info1.ce9705.December20Activity;
import edu.nyu.info1.ce9705.json.facebook.FacebookJsonDao;

/**
 * @author besseym
 *
 */
public class SearchPostTask extends AsyncTask<String, Integer, PostQueryResult> {
	
	private Boolean taskError;
	
	private December20Activity activity;
	private DialogFragment progressFragment;
	
	/**
	 * 
	 * @param listActivity
	 */
	public SearchPostTask(December20Activity activity, DialogFragment progressFragment){
		
		this.taskError = new Boolean(false);
		this.activity = activity;
		this.progressFragment = progressFragment;
	}

	/*
	 * (non-Javadoc)
	 * @see android.os.AsyncTask#doInBackground(Params[])
	 */
	@Override
	protected PostQueryResult doInBackground(String... queryArray) {
		
		this.taskError = new Boolean(false);
		
		PostQueryResult postQueryResult = null;
		
		String query = queryArray[0];
		if(query != null && !"".equals(query)){
			try{
				FacebookJsonDao facebookJsonDao = new FacebookJsonDao();
				postQueryResult = facebookJsonDao.searchPost(query);
				
			} catch (Exception e) {
				this.taskError = new Boolean(true);
				Log.e(QueryUserTask.class.toString(), e.getMessage(), e);
			}
		}
		
		return postQueryResult;
	}
	
	@Override
	protected void onProgressUpdate(Integer... progress) {
		
    }

	/*
	 * (non-Javadoc)
	 * @see android.os.AsyncTask#onPostExecute(java.lang.Object)
	 */
	@Override
    protected void onPostExecute(PostQueryResult postQueryResult) {
		
		if(!this.taskError){
			activity.setPostQueryResult(postQueryResult);
		}
		else{
			activity.onQueryError();
		}
		
		progressFragment.dismiss();
    }

}
