/**
 * 
 */
package edu.nyu.info1.ce9705.json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

/**
 * @author besseym
 *
 */
public class JsonDao {

	/**
	 * 
	 */
	public JsonDao() {
		
	}
	
	/**
	 * 
	 * @param url
	 * @return
	 * @throws JSONException
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public JSONObject parseJson(String url) throws JSONException, ClientProtocolException, IOException {
		return new JSONObject(readUrl(url));
	}
	
	/**
	 * 
	 * @param url
	 * @return
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public String readUrl(String url) throws ClientProtocolException, IOException {
		
		StringBuilder builder = new StringBuilder();
		
		HttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(url);
		
		HttpResponse response = client.execute(httpGet);
		StatusLine statusLine = response.getStatusLine();
		int statusCode = statusLine.getStatusCode();
		if (statusCode == 200) {
			HttpEntity entity = response.getEntity();
			InputStream content = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(content));
			
			String line = null;
			while ((line = reader.readLine()) != null) {
				builder.append(line);
			}
			
		} else {
			Log.e(JsonDao.class.toString(), "Failed to read url");
		}
		
		return builder.toString();
	}

}
