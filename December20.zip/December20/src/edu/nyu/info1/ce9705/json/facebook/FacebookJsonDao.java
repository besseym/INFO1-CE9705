/**
 * 
 */
package edu.nyu.info1.ce9705.json.facebook;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;
import edu.nyu.info1.ce9705.facebook.Post;
import edu.nyu.info1.ce9705.facebook.User;
import edu.nyu.info1.ce9705.json.JsonDao;
import edu.nyu.info1.ce9705.search.PostQueryResult;

/**
 * @author besseym
 *
 */
public class FacebookJsonDao extends JsonDao {

	/**
	 * 
	 */
	public FacebookJsonDao() {
		super();
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 * @throws JSONException
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public User queryUser(Integer id) throws JSONException, ClientProtocolException, IOException {
		
		String url = "https://graph.facebook.com/" + id;
		Log.i(FacebookJsonDao.class.toString(), url);
		
		User user = null;
		
		JSONObject jsonObject = this.parseJson(url);
		
		if(jsonObject != null){
			user = new User();
			this.populateUser(user, jsonObject);
		}
		
		return user;
	}
	
	/**
	 * 
	 * @param query
	 * @return
	 * @throws JSONException 
	 * @throws IOException 
	 * @throws ClientProtocolException 
	 */
	public PostQueryResult searchPost(String query) throws JSONException, ClientProtocolException, IOException {
		
		String url = "https://graph.facebook.com/search?q=" + query + "&type=post";
		
		PostQueryResult postQueryResult = null;
		
		JSONObject jsonObject = this.parseJson(url);
		if(jsonObject != null){
			
			Post post = null;
			postQueryResult = new PostQueryResult();
			
			JSONArray jsonArray = jsonObject.getJSONArray("data");
			for (int i = 0; i < jsonArray.length(); i++) {
				
				jsonObject = jsonArray.getJSONObject(i);
				
				post = new Post();
				this.populatePost(post, jsonObject);
				
				postQueryResult.getPostList().add(post);
			}
		}
		
		return postQueryResult;
	}
	
	/**
	 * 
	 * @param jsonObject
	 * @return
	 * @throws JSONException
	 */
	public void populatePost(Post post, JSONObject jsonObject) throws JSONException{
		
		post.setId(jsonObject.getString("id"));
		post.setMessage(jsonObject.optString("message"));
		
		this.populateUser(post.getFrom(), jsonObject.getJSONObject("from"));
	}
	
	/**
	 * 
	 * @param user
	 * @param jsonObject
	 * @throws JSONException
	 */
	public void populateUser(User user, JSONObject jsonObject) throws JSONException {
		
		user.setId(jsonObject.getInt("id"));
		user.setName(jsonObject.getString("name"));
		user.setFirstName(jsonObject.optString("first_name"));
		user.setLastName(jsonObject.optString("last_name"));
		user.setGender(jsonObject.optString("gender"));
		user.setLocal(jsonObject.optString("locale"));
		user.setLink(jsonObject.optString("link"));
	}

}
