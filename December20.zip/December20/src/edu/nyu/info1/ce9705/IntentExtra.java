/**
 * 
 */
package edu.nyu.info1.ce9705;

/**
 * @author besseym
 *
 */
public class IntentExtra {
	
	public static final String POST_QUERY_RESULT_EXTRA = "postQueryResult";
	public static final String USER_EXTRA = "user";

	/**
	 * 
	 */
	private IntentExtra() {}

}
