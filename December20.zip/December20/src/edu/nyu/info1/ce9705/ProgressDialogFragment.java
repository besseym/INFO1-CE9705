/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.os.Bundle;

/**
 * @author besseym
 *
 */
public class ProgressDialogFragment extends DialogFragment {

	/**
	 * 
	 * @param title
	 * @return
	 */
	public static ProgressDialogFragment newInstance() {
		ProgressDialogFragment fragment = new ProgressDialogFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }
	
	/*
	 * (non-Javadoc)
	 * @see android.app.DialogFragment#onCreateDialog(android.os.Bundle)
	 */
	@Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		String message = getString(R.string.query_progress);
        
        final ProgressDialog dialog = new ProgressDialog(getActivity());
        dialog.setMessage(message);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		dialog.setIndeterminate(true);
		dialog.setCancelable(false);

        return dialog;
    }

}
