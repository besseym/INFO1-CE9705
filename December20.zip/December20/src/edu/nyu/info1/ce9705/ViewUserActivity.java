/**
 * 
 */
package edu.nyu.info1.ce9705;

import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import edu.nyu.info1.ce9705.facebook.User;

/**
 * @author besseym
 *
 */
public class ViewUserActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_view);
		
		Bundle extras = getIntent().getExtras();
		final User user = (User) extras.get(IntentExtra.USER_EXTRA);
		
		TextView userIdText = (TextView)findViewById(R.id.user_id);
		userIdText.setText(user.getId().toString());
		
		TextView userUserNameText = (TextView)findViewById(R.id.user_username);
		userUserNameText.setText(user.getUsername());
		
		TextView userEmailText = (TextView)findViewById(R.id.user_email);
		userEmailText.setText(user.getEmail());
		
		TextView userNameText = (TextView)findViewById(R.id.user_name);
		userNameText.setText(user.getName());
		
		TextView userGenderText = (TextView)findViewById(R.id.user_gender);
		userGenderText.setText(user.getGender());
		
		TextView userLocalText = (TextView)findViewById(R.id.user_local);
		userLocalText.setText(user.getLocal());
		
		TextView userLinkText = (TextView)findViewById(R.id.user_link);
		userLinkText.setText(user.getLink());
		
		Button createContactButton = (Button)findViewById(R.id.create_contact);
		createContactButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				ArrayList<ContentProviderOperation> operations = new ArrayList<ContentProviderOperation>();
				operations.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
		                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
		                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
		                .build());
				operations.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
		                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
		                .withValue(ContactsContract.Data.MIMETYPE,
		                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
		                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, user.getName())
		                .build());
				
				String email = user.getEmail();
				if(email != null && !"".equals(email)){
					operations.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
			                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
			                .withValue(ContactsContract.Data.MIMETYPE,
			                        ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
			                .withValue(ContactsContract.CommonDataKinds.Email.DATA, email)
			                .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_HOME)
			                .build());
				}
		        
		        try {
		            getContentResolver().applyBatch(ContactsContract.AUTHORITY, operations);
		            
		            Toast.makeText(ViewUserActivity.this, R.string.create_contact_success, Toast.LENGTH_SHORT).show();
		        } catch (Exception e) {
		        	
		            Toast.makeText(ViewUserActivity.this, R.string.create_contact_error, Toast.LENGTH_LONG).show();

		            // Log exception
		            Log.e(ViewUserActivity.class.toString(), "Exception encoutered while inserting contact: " + e);
		        }
				
				
			}
		});
	}

}
