/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import edu.nyu.info1.ce9705.facebook.User;
import edu.nyu.info1.ce9705.search.QueryUserTask;

/**
 * @author besseym
 *
 */
public class ViewUserActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.user_view);
		
		Bundle extras = getIntent().getExtras();
		User user = (User) extras.get(IntentExtra.USER_EXTRA);
		
		TextView userIdText = (TextView)findViewById(R.id.user_id);
		userIdText.setText(user.getId().toString());
		
		TextView userNameText = (TextView)findViewById(R.id.user_name);
		userNameText.setText(user.getName());
		
		TextView userGenderText = (TextView)findViewById(R.id.user_gender);
		userGenderText.setText(user.getGender());
		
		TextView userLocalText = (TextView)findViewById(R.id.user_local);
		userLocalText.setText(user.getLocal());
		
		TextView userLinkText = (TextView)findViewById(R.id.user_link);
		userLinkText.setText(user.getLink());
	}

}
