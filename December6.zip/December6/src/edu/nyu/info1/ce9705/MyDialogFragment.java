/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

import org.json.JSONArray;

/**
 * @author besseym
 *
 */
public class MyDialogFragment extends DialogFragment {
	
	private static final String TITLE_ARG = "title";
	private static final String ITEMS_ARG = "items";
	
	/**
	 * 
	 * @param title
	 * @return
	 */
	public static MyDialogFragment newInstance(int title, ColorEnum [] colorEnumArray) {
		
		int numberOfItems = colorEnumArray.length;
		CharSequence [] itemArray = new String [numberOfItems];
		for(int i = 0; i < numberOfItems; i++){
			itemArray[i] = colorEnumArray[i].getDisplayName();
		}
		
		MyDialogFragment dialogFragment = new MyDialogFragment();
        Bundle args = new Bundle();
        args.putInt(TITLE_ARG, title);
        args.putCharSequenceArray(ITEMS_ARG, itemArray);
        dialogFragment.setArguments(args);
        
        return dialogFragment;
    }
	
	/*
	 * (non-Javadoc)
	 * @see android.app.DialogFragment#onCreateDialog(android.os.Bundle)
	 */
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		int title = getArguments().getInt(TITLE_ARG);
		CharSequence [] itemArray = getArguments().getCharSequenceArray(ITEMS_ARG);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(this.getActivity());
		builder.setTitle(title);
		builder.setItems(itemArray, new DialogInterface.OnClickListener() {
		    public void onClick(DialogInterface dialog, int item) {
		        ((December6Activity) getActivity()).setBackgroundColor(item);
		    }
		});
		
		return builder.create();
	}

}
