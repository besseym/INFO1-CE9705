/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.graphics.Color;

/**
 * @author besseym
 *
 */
public enum ColorEnum {
	
	BLACK(Color.BLACK, "Black"),
	BLUE(Color.BLUE, "Blue"),
	CYAN(Color.CYAN, "Cyan"),
	DKGRAY(Color.DKGRAY, "Dark Gray"),
	GRAY(Color.GRAY, "Gray"),
	GREEN(Color.GREEN, "Green"),
	LTGRAY(Color.LTGRAY, "Light Gray"),
	MAGENTA(Color.MAGENTA, "Magenta"),
	RED(Color.RED, "Red"),
	WHITE(Color.WHITE, "White"),
	YELLOW(Color.YELLOW, "Yellow");
	
	private Integer value;
	private String displayName;
	private ColorEnum(Integer value, String displayName){
		this.value = value;
		this.displayName = displayName;
	}
	/**
	 * @return the value
	 */
	public Integer getValue() {
		return value;
	}
	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

}
