package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class December6Activity extends Activity {
	
	private LinearLayout mainLayout;
	private ColorEnum [] colorEnumArray;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.main);
        mainLayout = (LinearLayout)findViewById(R.id.main_layout);
        
        colorEnumArray = new ColorEnum [] {ColorEnum.BLACK, ColorEnum.BLUE, ColorEnum.CYAN, ColorEnum.DKGRAY, ColorEnum.GRAY, ColorEnum.GREEN, ColorEnum.LTGRAY, ColorEnum.MAGENTA, ColorEnum.RED, ColorEnum.WHITE, ColorEnum.YELLOW};
        
        final Button button = (Button)findViewById(R.id.dialogCallButton);

		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				showDialog();
			}
		});
    }
    
    /**
     * 
     * @param index
     */
    public void setBackgroundColor(int index){
    	
    	ColorEnum color = this.colorEnumArray[index];
    	mainLayout.setBackgroundColor(color.getValue());
    }
    
    /**
     * 
     */
    private void showDialog() {
        DialogFragment newFragment = MyDialogFragment.newInstance(R.string.dialog_title, colorEnumArray);
        newFragment.show(getFragmentManager(), "dialog");
    }
}