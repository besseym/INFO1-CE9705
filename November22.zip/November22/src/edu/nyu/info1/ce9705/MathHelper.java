/**
 * 
 */
package edu.nyu.info1.ce9705;

/**
 * @author besseym
 *
 */
public class MathHelper {

	/**
	 * 
	 */
	private MathHelper() {}
	
	/**
	 * 
	 * @param f1
	 * @param f2
	 * @return
	 */
	public static float calcAbsDifference(float f1, float f2){
		
		float absF1 = Math.abs(f1);
		float absF2 = Math.abs(f2);
		
		return (absF1 > absF2) ? absF1 - absF2 : absF2 - absF1;
	}
}
