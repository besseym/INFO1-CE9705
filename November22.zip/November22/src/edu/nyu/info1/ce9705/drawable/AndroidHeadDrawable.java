/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.shapes.ArcShape;

/**
 * @author besseym
 *
 */
public class AndroidHeadDrawable extends AndroidPartDrawable {
	
	private AndroidEyeDrawable leftEye;
	private AndroidEyeDrawable rightEye;
	
	private Paint eyePaint;
	private Paint antenaPaint;

	/**
	 * Constructor
	 * 
	 * @param width
	 * @param height
	 */
	public AndroidHeadDrawable(Integer width, Integer height, Paint primaryPaint, Paint secondaryPaint) {
		super(new ArcShape(0.0f, 180.0f), width, height, primaryPaint);
		
		Integer eyeDiameter = new Integer((int)( width * 0.15f));
		
		this.eyePaint = secondaryPaint;
		this.antenaPaint = primaryPaint;
		
		this.leftEye = new AndroidEyeDrawable(eyeDiameter, eyeDiameter, this.eyePaint);
		this.rightEye = new AndroidEyeDrawable(eyeDiameter, eyeDiameter, this.eyePaint);
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		
		drawAntena(canvas);
		
		canvas.save();
		
		canvas.translate(centerX, centerY);
		super.draw(canvas);
		this.updateLocationInformation(canvas.getMatrix());
		
		canvas.restore();
		
		//draw eyes
		
		float eyeX = (this.width * 0.25f);
		float eyeY = (this.height * 0.25f);
		
		canvas.save();
		
		canvas.translate(0, eyeY);
		
		canvas.save();
		canvas.translate(-eyeX, 0);
		this.leftEye.draw(canvas);
		canvas.restore();
		
		canvas.save();
		canvas.translate(eyeX, 0);
		this.rightEye.draw(canvas);
		canvas.restore();
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param paint
	 */
	private void drawAntena(Canvas canvas) {
		
		Paint paint = new Paint(this.antenaPaint);
		paint.setStrokeWidth((int) (this.width * 0.05));
		paint.setStyle(Paint.Style.STROKE);
		
		int antenaStart = (int) (this.width * 0.2);
		int antenaLength = (int) (this.width * 0.4);
		
		float antena_OffCenterY = (this.height * 0.125f);
		
		canvas.save();
		
		canvas.translate(0, antena_OffCenterY);
		
		canvas.drawLine(antenaStart, 0, antenaLength, antenaLength, paint);
		canvas.drawLine(-antenaStart, 0, -antenaLength, antenaLength, paint);
		
		canvas.restore();
	}

}
