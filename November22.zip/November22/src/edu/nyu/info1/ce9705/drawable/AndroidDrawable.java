/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import edu.nyu.info1.ce9705.MathHelper;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.drawable.shapes.RectShape;
import android.util.Log;

/**
 * @author besseym
 *
 */
public class AndroidDrawable extends AndroidPartDrawable {
	
	private Float rounding;
	
	private AndroidHeadDrawable head;
	private AndroidBodyDrawable body;
	
	private AndroidArmDrawable leftArm;
	private AndroidArmDrawable rightArm;
	
	private AndroidLegDrawable leftLeg;
	private AndroidLegDrawable rightLeg;
	
	private Paint primaryPaint;
	private Paint secondaryPaint;
	
	protected Float moveInputX;
	protected Float moveInputY;
	
	private Boolean leftArmTouched;
	private Boolean rightArmTouched;
	
	private Boolean isBodyTouched;
	
	/**
	 * Constructor
	 * @param size
	 */
	public AndroidDrawable(Integer size, Paint primaryPaint, Paint secondaryPaint) {
		this(size, size, primaryPaint, secondaryPaint);
	}
	
	/**
	 * Constructor
	 * @param width
	 * @param height
	 */
	public AndroidDrawable(Integer width, Integer height, Paint primaryPaint, Paint secondaryPaint) {
		super(new RectShape(), width, height, primaryPaint);
		
		this.primaryPaint = primaryPaint;
		this.secondaryPaint = secondaryPaint;
		
		this.rounding = new Float(width * 0.075);
		
		Integer headWidth = new Integer((int) (width * 0.55));
		Integer headHeight = new Integer((int) (height * 0.45));
		this.head = new AndroidHeadDrawable(headWidth, headHeight, this.primaryPaint, this.secondaryPaint);
		
		Integer bodyWidth = new Integer(headWidth);
		Integer bodyHeight = new Integer((int) (height * 0.5));
		this.body = new AndroidBodyDrawable(bodyWidth, bodyHeight, this.rounding, this.primaryPaint);
		this.body.setRounding(this.rounding);
		
		Integer armWidth = new Integer((int) (bodyWidth * 0.25));
		Integer armHeight = new Integer((int) (bodyHeight * 0.75));
		this.leftArm = new AndroidArmDrawable(armWidth, armHeight, this.rounding, this.primaryPaint);
		this.leftArm.setRounding(this.rounding);
		this.leftArm.setRotationalDirection(-1.0f);
		
		this.rightArm = new AndroidArmDrawable(armWidth, armHeight, this.rounding, this.primaryPaint);
		this.rightArm.setRounding(this.rounding);
		
		Integer legWidth = new Integer((int) (bodyWidth * 0.25));
		Integer legHeight = new Integer((int) (bodyHeight * 0.55));
		this.leftLeg = new AndroidLegDrawable(legWidth, legHeight, this.rounding, this.primaryPaint);
		this.leftLeg.setRounding(this.rounding);
		this.rightLeg = new AndroidLegDrawable(legWidth, legHeight, this.rounding, this.primaryPaint);
		this.rightLeg.setRounding(this.rounding);
		
		this.leftArmTouched = new Boolean(false);
		this.rightArmTouched = new Boolean(false);
		
		this.isBodyTouched = new Boolean(false);
		
		this.moveInputX = -1.0f;
		this.moveInputY = -1.0f;
		
		this.setBounds(0, 0, width, height);
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		
		canvas.save();
		
		Matrix matrix = canvas.getMatrix();
		
		Log.i("my_tag", moveInputX + " : " + moveInputY);
		if(this.moveInputX >= 0.0f && this.moveInputY >= 0.0f){
			
			Matrix inverseMatrix = new Matrix();
			matrix.invert(inverseMatrix);
			
			float [] pointArray = {this.moveInputX, this.moveInputY};
			inverseMatrix.mapPoints(pointArray);
			canvas.translate(pointArray[0], pointArray[1]);
		}
		
		canvas.save();
		canvas.translate(0, (this.body.getHeight() * 0.55f));
		this.head.draw(canvas);
		canvas.restore();
		
		this.body.draw(canvas);
		
		//draw arms
		float armX = this.body.getWidth() * 0.65f;
		float armY = this.body.getHeight() * 0.125f;
		
		canvas.save();
		canvas.translate(-armX, armY);
		this.leftArm.draw(canvas);
		canvas.restore();
		
		canvas.save();
		canvas.translate(armX, armY);
		this.rightArm.draw(canvas);
		canvas.restore();
		
		//draw legs
		float legX = this.body.getWidth() * 0.25f;
		float legY = -(this.body.getHeight() * 0.65f);
		
		canvas.save();
		canvas.translate(-legX, legY);
		this.leftLeg.draw(canvas);
		canvas.restore();
		
		canvas.save();
		canvas.translate(legX, legY);
		this.rightLeg.draw(canvas);
		canvas.restore();
		
		this.updateLocationInformation(matrix);
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @param paint
	 */
	public void colorIfTouched(float x, float y, Paint paint){
		
		this.head.colorIfTouched(x, y, paint);
		this.body.colorIfTouched(x, y, paint);
		this.leftArm.colorIfTouched(x, y, paint);
		this.rightArm.colorIfTouched(x, y, paint);
		this.leftLeg.colorIfTouched(x, y, paint);
		this.rightLeg.colorIfTouched(x, y, paint);
	}
	
	/**
	 * 
	 */
	public void reset(){
		
		this.head.resetColor();
		this.body.resetColor();
		this.leftArm.resetColor();
		this.rightArm.resetColor();
		this.leftLeg.resetColor();
		this.rightLeg.resetColor();
		
		this.leftArmTouched = new Boolean(false);
		this.rightArmTouched = new Boolean(false);
		
		this.isBodyTouched = new Boolean(false);
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 */
	public void touch(float x, float y){
		
		this.leftArmTouched = this.leftArm.isTouched(x, y);
		this.rightArmTouched = this.rightArm.isTouched(x, y);
		
		this.isBodyTouched = this.body.isTouched(x, y);
	}
	
	/**
	 * 
	 * @param inputX
	 */
	public void moveIfTouched(float inputX, float inputY){
		
		if(!this.isBodyTouched){
			return;
		}
		
		this.moveInputX = inputX;
		this.moveInputY = inputY;
	}
	
	/**
	 * 
	 * @param touchX
	 * @param touchY
	 * @param rotateX
	 * @param rotateY
	 */
	public void rotateIfTouched(float x, float y){
		
		if(this.leftArmTouched){
			this.leftArm.rotate(x, y);
		}
		
		if(this.rightArmTouched){
			this.rightArm.rotate(x, y);
		}
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#getOpacity()
	 */
	@Override
	public int getOpacity() {
		return PixelFormat.OPAQUE;
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#setAlpha(int)
	 */
	@Override
	public void setAlpha(int alpha) {
		this.head.setAlpha(alpha);
		this.body.setAlpha(alpha);
		this.leftArm.setAlpha(alpha);
		this.rightArm.setAlpha(alpha);
		this.leftLeg.setAlpha(alpha);
		this.rightLeg.setAlpha(alpha);
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#setColorFilter(android.graphics.ColorFilter)
	 */
	@Override
	public void setColorFilter(ColorFilter cf) {
		
		this.head.setColorFilter(cf);
		this.body.setColorFilter(cf);
		this.leftArm.setColorFilter(cf);
		this.rightArm.setColorFilter(cf);
		this.leftLeg.setColorFilter(cf);
		this.rightLeg.setColorFilter(cf);
	}

}
