/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.shapes.OvalShape;

/**
 * @author besseym
 *
 */
public class AndroidEyeDrawable extends AndroidPartDrawable {

	/**
	 * Constructor
	 * @param width
	 * @param height
	 */
	public AndroidEyeDrawable(Integer width, Integer height, Paint primaryPaint) {
		super(new OvalShape(), width, height, primaryPaint);
		this.getPaint().set(primaryPaint);
	}
	
	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		
		canvas.save();
		
		canvas.translate(centerX, centerY);
		super.draw(canvas);
		this.updateLocationInformation(canvas.getMatrix());
		
		canvas.restore();
	}

}
