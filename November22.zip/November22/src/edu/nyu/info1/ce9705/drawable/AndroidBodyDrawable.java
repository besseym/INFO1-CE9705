/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.shapes.RoundRectShape;

/**
 * @author besseym
 *
 */
public class AndroidBodyDrawable extends AndroidPartDrawable {

	/**
	 * Constructor
	 * 
	 * @param width
	 * @param height
	 */
	public AndroidBodyDrawable(Integer width, Integer height, Float rounding, Paint primaryPaint) {
		super(new RoundRectShape(new float[] { rounding, rounding, rounding, rounding, 0, 0, 0, 0 }, null, null), width, height, primaryPaint);
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		
		canvas.save();
		canvas.translate(centerX, centerY);
		super.draw(canvas);
		this.updateLocationInformation(canvas.getMatrix());
		canvas.restore();
	}

}
