/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.shapes.RoundRectShape;

/**
 * @author besseym
 *
 */
public class AndroidArmDrawable extends AndroidPartDrawable {
	
	private PointF rotatePoint;
	private PointF rotatePointLocation;
	
	private Float rotationDegrees;
	private Float rotationalDirection;

	/**
	 * Constructor
	 * 
	 * @param width
	 * @param height
	 */
	public AndroidArmDrawable(Integer width, Integer height, Float rounding, Paint primaryPaint) {
		super(new RoundRectShape(new float[] { rounding, rounding, rounding, rounding, rounding, rounding, rounding, rounding }, null, null), width, height, primaryPaint);
		
		this.rotationDegrees = new Float(0.0f);
		this.rotationalDirection = new Float(1.0f);
		
		this.rotatePoint = new PointF((this.width * 0.5f), this.height);
		this.rotatePointLocation = new PointF(this.rotatePoint.x, this.rotatePoint.y);
	}

	/* (non-Javadoc)
	 * @see android.graphics.drawable.Drawable#draw(android.graphics.Canvas)
	 */
	@Override
	public void draw(Canvas canvas) {
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.rotate(this.rotationalDirection * this.rotationDegrees, this.rotatePoint.x, this.rotatePoint.y);
		super.draw(canvas);
		this.updateRotatePoint(canvas.getMatrix());
		this.updateLocationInformation(canvas.getMatrix());
		canvas.restore();

	}
	
	/**
	 * 
	 * @param inputX
	 * @param inputY
	 */
	public void rotate(float inputX, float inputY){
		
		float absInputX = Math.abs(inputX);
		float absInputY = Math.abs(inputY);
		
		float absRotatePointX = Math.abs(this.rotatePointLocation.x);
		float absRotatePointY = Math.abs(this.rotatePointLocation.y);
		
		//if rotation direction negative only rotate if input x is less than rotate x
		if(this.rotationalDirection < 0 && absInputX >= absRotatePointX){
			return;
		}
		
		//if rotation direction positive only rotate if input x is greater than rotate x
		if(this.rotationalDirection > 0 && absInputX <= absRotatePointX){
			return;
		}
		
		float degrees = 0;
		
		float x = absRotatePointX - absInputX;
		float y = absRotatePointY - absInputY;
		
		if(absInputX > absRotatePointX){
			x = absInputX - absRotatePointX;
		}
		
		if(absInputY > absRotatePointY){
			y = absInputY - absRotatePointY;
		}
		
		float degreeChange = (float) Math.toDegrees(Math.atan2(x, y));
		
		if(absInputY <= absRotatePointY){
			degrees = 90 + (90 - degreeChange);
		}
		else {
			degrees += degreeChange;
		}
		
		this.setRotationDegrees(degrees);
	}
	
	/**
	 * 
	 * @param matrix
	 */
	public void updateRotatePoint(Matrix matrix){
		
		float [] pointArray = {this.rotatePoint.x, this.rotatePoint.y};
		matrix.mapPoints(pointArray);
		this.rotatePointLocation = new PointF(pointArray[0], pointArray[1]);
	}

	/**
	 * @param rotationalDirection the rotationalDirection to set
	 */
	public void setRotationalDirection(Float rotationalDirection) {
		if(rotationalDirection == 1.0f || rotationalDirection == -1.0f){
			this.rotationalDirection = rotationalDirection;
		}
	}

	/**
	 * @param rotationDegrees the rotationDegrees to set
	 */
	public void setRotationDegrees(Float rotationDegrees) {
		this.rotationDegrees = rotationDegrees;
	}

}
