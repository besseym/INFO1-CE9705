/**
 * 
 */
package edu.nyu.info1.ce9705.drawable;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.Shape;

/**
 * @author besseym
 *
 */
public abstract class AndroidPartDrawable extends ShapeDrawable {
	
	protected Integer width;
	protected Integer height;
	
	protected Float rounding;
	
	protected Float offsetX;
	protected Float offsetY;
	
	protected PointF center;
	protected PointF centerLocation;
	private RectF touchRectRegion;
	
	private Paint defaultPaint;

	/**
	 * Constructor
	 * 
	 * @param shape
	 * @param width
	 * @param height
	 */
	public AndroidPartDrawable(Shape shape, Integer width, Integer height, Paint defaultPaint) {
		super(shape);
		
		this.width = width;
		this.height = height;
		
		Rect bounds = new Rect(0, 0, width, height);
		this.setBounds(bounds);
		this.touchRectRegion = new RectF(bounds);
		
		this.resetOffset();
		
		this.rounding = new Float(0.0f);
		
		this.defaultPaint = defaultPaint;
		this.getPaint().set(defaultPaint);
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		this.center = new PointF(centerX, centerY);
		this.centerLocation = new PointF(centerX, centerY);
	}
	
	/**
	 * 
	 */
	public void resetOffset(){
		
		this.offsetX = new Float(0.0f);
		this.offsetY = new Float(0.0f);
	}
	
	/**
	 * 
	 * @param canvas
	 */
	protected void applyBaseTransform(Canvas canvas){
		canvas.translate(this.offsetX, this.offsetY);
	}
	
	/**
	 * 
	 */
	public void resetColor(){
		this.getPaint().set(this.defaultPaint);
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean isTouched(float x, float y){
		return this.touchRectRegion.contains(x, y);
	}
	
	/**
	 * 
	 * @param x
	 * @param y
	 * @param paint
	 */
	public void colorIfTouched(float x, float y, Paint paint){
		
		if(this.touchRectRegion.contains(x, y)) {
			this.getPaint().set(paint);
		}
	}
	
	/**
	 * @param matrix the matrix to set
	 */
	public void updateLocationInformation(Matrix matrix) {
		
		float centerX = -(this.width * 0.5f);
		float centerY = -(this.height * 0.5f);
		
		float [] pointArray = {centerX, centerY};
		matrix.mapPoints(pointArray);
		this.centerLocation = new PointF(pointArray[0], pointArray[1]);
		
		this.touchRectRegion = new RectF(this.getBounds());
		matrix.mapRect(this.touchRectRegion);
	}

	/**
	 * @return the center
	 */
	public PointF getCenter() {
		return center;
	}

	/**
	 * @return the centerLocation
	 */
	public PointF getCenterLocation() {
		return centerLocation;
	}

	/**
	 * @return the touchRectRegion
	 */
	public RectF getTouchRectRegion() {
		return touchRectRegion;
	}

	/**
	 * @return the width
	 */
	public Integer getWidth() {
		return width;
	}

	/**
	 * @return the height
	 */
	public Integer getHeight() {
		return height;
	}

	/**
	 * @param rounding the rounding to set
	 */
	public void setRounding(Float rounding) {
		this.rounding = rounding;
	}

}
