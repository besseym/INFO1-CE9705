package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.os.Bundle;

public class November22Activity extends Activity {
	
    /** 
     * Called when the activity is first created.
     * 
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.main);
        
        final DrawableView androidView = new DrawableView(this);
        this.setContentView(androidView);
    }
}