/**
 * 
 */
package edu.nyu.info1.ce9705;

import java.util.Random;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import edu.nyu.info1.ce9705.drawable.AndroidDrawable;

/**
 * @author besseym
 *
 */
public class DrawableView extends View {
	
	private static String logTag = "my_tag";
	
	private AndroidDrawable [] androidArray ; 

	/**
	 * @param context
	 */
	public DrawableView(final Context context) {
		super(context);
		
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(Color.GREEN);
		paint.setStyle(Paint.Style.FILL);
		
		Paint [] paintArray = new Paint [3];
		paintArray[0] = new Paint(paint);
		paintArray[1] = new Paint(paint);
		paintArray[1].setColor(Color.rgb(0, 200, 0));
		paintArray[2] = new Paint(paint);
		paintArray[2].setColor(Color.rgb(0, 150, 0));
		
		Paint secondaryPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		secondaryPaint.setColor(Color.WHITE);
		secondaryPaint.setStyle(Paint.Style.FILL);
		
		int androidSize = 300;
		Random random = new Random();
		
		int numberOfAndroids = 3;
		this.androidArray = new AndroidDrawable [numberOfAndroids];
		for(int i = 0; i < numberOfAndroids; i++){
			androidSize = random.nextInt(300);
			this.androidArray[i] = new AndroidDrawable(androidSize, paintArray[i], secondaryPaint);
		}
		
		final Paint touchPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		touchPaint.setColor(Color.RED);
		touchPaint.setStyle(Paint.Style.FILL);
		
		final GestureDetector gestureDetector = new GestureDetector(new GestureDetector.OnGestureListener() {
			
			
			@Override
			public boolean onSingleTapUp(MotionEvent event){
				
				float x = event.getX();
				float y = event.getY();
				Log.i(logTag, "onSingleTapUp - event(" + x + " : " + y + ")");
				
				return true;
			}

			@Override
			public boolean onDown(MotionEvent event) {
				
				float x = event.getX();
				float y = event.getY();
				Log.i(logTag, "onDown - event(" + x + " : " + y + ")");
				
				for(AndroidDrawable android : androidArray){
					android.colorIfTouched(x, y, touchPaint);
					android.touch(x, y);
				}
				
				return true;
			}

			@Override
			public boolean onFling(MotionEvent event1, MotionEvent event2, float arg2, float arg3) {
				
				float x1 = event1.getX();
				float y1 = event1.getY();
				
				float x2 = event2.getX();
				float y2 = event2.getY();
				
				Log.i(logTag, "onFling - event1(" + x1 + " : " + y1 + ") & event2(" + x2 + " : " + y2 + ")");
				
				return true;
			}

			@Override
			public void onLongPress(MotionEvent event) {
				
				float x = event.getX();
				float y = event.getY();
				Log.i(logTag, "onLongPress - event(" + x + " : " + y + ")");
			}

			@Override
			public boolean onScroll(MotionEvent event1, MotionEvent event2, float arg2, float arg3) {
				
				float x1 = event1.getX();
				float y1 = event1.getY();
				
				float x2 = event2.getX();
				float y2 = event2.getY();
				
				Log.i(logTag, "onScroll - event1(" + x1 + " : " + y1 + ") & event2(" + x2 + " : " + y2 + ")");
				
				for(AndroidDrawable android : androidArray){
					android.rotateIfTouched(event2.getX(), event2.getY());
					android.moveIfTouched(event2.getX(), event2.getY());
				}
				
				return true;
			}

			@Override
			public void onShowPress(MotionEvent event) {
				
				float x = event.getX();
				float y = event.getY();
				Log.i(logTag, "onShowPress - event(" + x + " : " + y + ")");
			}
		});
		
		setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				
				boolean onTouch = true;
				
				switch(event.getAction()) {
					case MotionEvent.ACTION_UP:
						
						for(AndroidDrawable android : androidArray){
							android.reset();
						}
						break;
					default:
						onTouch = gestureDetector.onTouchEvent(event);
						break;
				}
				
				invalidate();
				
				return onTouch;
			}
		});
	}
	
	/*
	 * (non-Javadoc)
	 * @see android.view.View#onDraw(android.graphics.Canvas)
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		
		final int width = this.getWidth();
		final int height = this.getHeight();
		
		canvas.drawColor(Color.WHITE);
		
		canvas.save();
		
		//translate to center of view
		canvas.translate(width * 0.5f, height * 0.5f);
		
		//Make the Y axis point up.
		canvas.scale(1, -1);
		
		float x = -100.0f;
		float y = -250.0f;
		
		for(AndroidDrawable android : androidArray){
			
			canvas.save();
			canvas.translate(x, y);
			android.draw(canvas);
			canvas.restore();
			
			y += 250.0f;
			x += 100f;
		}
		
		canvas.restore();
	}

}
