/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * @author besseym
 *
 */
public class CountThread extends Thread {
	
	private Integer count;
	private Handler handler;

	/**
	 * Constructor
	 * @param handler
	 */
	public CountThread(Integer count, Handler handler) {
		this.count = count;
		this.handler = handler;
	}
	
	@Override
	public void run() {
		
		for(int i = count; i >= 0; i--){
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}
			
			final Message message = handler.obtainMessage();
			message.arg1 = i;
			
			//Send the message to the Handler.
			handler.sendMessage(message);
		}
	}

}
