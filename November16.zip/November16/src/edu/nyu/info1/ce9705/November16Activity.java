package edu.nyu.info1.ce9705;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Toast;

public class November16Activity extends Activity {
	
	private Boolean isRunningAnimation = false;
	
	
    /*
     * (non-Javadoc)
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.main);
        
        final int androidSize = 10;
        final Android android = new Android(androidSize);
        
        final AndroidView androidView = new AndroidView(this, android);
        this.setContentView(androidView);
        
        final Handler handler = new Handler() {
			@Override
			public void handleMessage(Message message) {
				android.setSize(message.arg1);
				android.animateLegs();
				
				if(message.arg2 > 0){
					android.resetLegs();
					android.animateLeftArm();
					Toast.makeText(November16Activity.this, R.string.greeting_message, Toast.LENGTH_LONG).show();
					isRunningAnimation = false;
				}
				
				androidView.invalidate();
			}
        };
        
        final AnimateThread animateThread = new AnimateThread(androidSize, handler);
        androidView.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				
				if(!isRunningAnimation){
					isRunningAnimation = true;
					android.reset(androidSize);
					AnimateThread animateThread = new AnimateThread(androidSize, handler);
					animateThread.start();
				}
			}
        });
        
        Toast.makeText(November16Activity.this, R.string.start_message, Toast.LENGTH_LONG).show();
    }
}