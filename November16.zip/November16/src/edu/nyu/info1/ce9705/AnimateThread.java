/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * @author besseym
 *
 */
public class AnimateThread extends Thread {

	private Integer size;
	private Handler handler;
	
	/**
	 * Constructor
	 * @param handler
	 */
	public AnimateThread(Integer size, Handler handler) {
		this.size = size;
		this.handler = handler;
	}
	
	
	@Override
	public void run() {
		
		Message message = null;
		
		int maxIterations = 50;
		for(int i = 1; i < maxIterations; i++){
			
			try {
				Thread.sleep(250);
			} catch (InterruptedException e) {
				Log.e("ERROR", "Thread Interrupted");
			}
			
			message = handler.obtainMessage();
			message.arg1 = size * i;
			message.arg2 = 0;
			handler.sendMessage(message);
		}
		
		message = handler.obtainMessage();
		message.arg1 = size * maxIterations;
		message.arg2 = 1;
		handler.sendMessage(message);
	}

}
