/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/**
 * @author besseym
 *
 */
public class AndroidView extends View {
	
	private Android android;

	/**
	 * @param context
	 */
	public AndroidView(Context context, Android android) {
		super(context);
		this.android = android;
	}
	
	/*
	 * (non-Javadoc)
	 * @see android.view.View#onDraw(android.graphics.Canvas)
	 */
	@Override
	protected void onDraw(Canvas canvas) {
		
		final int width = this.getWidth();
		final int height = this.getHeight();
		
		canvas.drawColor(Color.WHITE);
		
		Paint androidPaint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
		androidPaint1.setColor(Color.GREEN);
		androidPaint1.setStyle(Paint.Style.FILL);
		
		Paint androidPaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
		androidPaint2.setColor(Color.WHITE);
		androidPaint2.setStyle(Paint.Style.FILL);
		
		//translate to center of view
		canvas.translate(width * 0.5f, height * 0.5f);
		
		//draw android
		android.draw(canvas, androidPaint1, androidPaint2);
		
	}
}
