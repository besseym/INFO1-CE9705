/**
 * 
 */
package edu.nyu.info1.ce9705;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

/**
 * @author besseym
 *
 */
public class Android {
	
	private Integer headWidth;
	private Integer headHeight;
	
	private Float eyeRadius;
	
	private Integer bodyWidth;
	private Integer bodyHeight;
	
	private Integer armWidth;
	private Integer armHeight;
	
	private Integer legWidth;
	private Integer legHeight;
	
	private Float rounding;
	
	private Integer leftLegOffset;
	private Integer rightLegOffset;
	
	private Integer leftArmOffset;

	/**
	 * Constructor
	 * @param size
	 */
	public Android(int size) {
		this(size, size);
	}
	
	/**
	 * Constructor
	 * 
	 * @param width
	 * @param height
	 */
	public Android(int width, int height) {
		setSize(width, height);
		
		this.leftLegOffset = 0;
		this.rightLegOffset = 0;
		
		this.leftArmOffset = 0;
	}
	
	/**
	 * 
	 * @param size
	 */
	public void setSize(int size) {
		this.setSize(size, size);
	}
	
	/**
	 * 
	 * @param width
	 * @param height
	 */
	public void setSize(int width, int height) {
		
		this.headWidth = new Integer((int) (width * 0.55));
		this.headHeight = new Integer((int) (height * 0.45));
		
		this.eyeRadius = new Float(headWidth * 0.05f);
		
		this.bodyWidth = new Integer(headWidth);
		this.bodyHeight = new Integer((int) (height * 0.5));
		
		this.armWidth = new Integer((int) (bodyWidth * 0.25));
		this.armHeight = new Integer((int) (bodyHeight * 0.75));
		
		this.legWidth = new Integer((int) (bodyWidth * 0.25));
		this.legHeight = new Integer((int) (bodyHeight * 0.55));
		
		this.rounding = new Float(width * 0.075);
	}
	
	/**
	 * 
	 * @param view
	 * @param canvas
	 * @param paint
	 */
	public void draw(Canvas canvas, Paint paint1, Paint paint2) {
		
		canvas.save();
		
		//Make the Y axis point up.
		canvas.scale(1, -1);
		
		drawHead(canvas, paint1, paint2);
		drawBody(canvas, paint1);
		drawArms(canvas, paint1);
		drawLegs(canvas, paint1);
		
		canvas.restore();
	}
	
	/**
	 * 
	 */
	public void animateLeftArm(){
		this.leftArmOffset = (int)(this.bodyHeight * 0.5);
	}
	
	/**
	 * 
	 */
	public void animateLegs(){
		
		int offset = (int)(this.legHeight * 0.5);
		
		if(this.leftLegOffset > 0){
			this.rightLegOffset = offset;
			this.leftLegOffset = 0;
		}
		else {
			this.leftLegOffset = offset;
			this.rightLegOffset = 0;
		}
	}
	
	/**
	 * 
	 */
	public void resetArms(){
		this.leftArmOffset = 0;
	}
	
	/**
	 * 
	 */
	public void resetLegs(){
		this.leftLegOffset = 0;
		this.rightLegOffset = 0;
	}
	
	/**
	 * 
	 */
	public void reset(int size){
		this.setSize(size);
		this.resetArms();
		this.resetLegs();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param width
	 * @param height
	 * @param paint
	 */
	private void drawHead(Canvas canvas, Paint paint1, Paint paint2) {
		
		float centerX = -(this.headWidth * 0.5f);
		float centerY = -(this.headHeight * 0.5f);
		float offCenterY = (this.bodyHeight * 0.55f);
		
		Rect rect = new Rect(0, 0, this.headWidth, this.headHeight);
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(0, offCenterY);
		
		canvas.drawArc(new RectF(rect), 0f, 180f, false, paint1);
		
		//translate to center of head
		canvas.translate((this.headWidth * 0.5f), (this.headHeight * 0.5f));
		
		//draw antena relative to head
		drawAntena(canvas, paint1);
		
		//draw eyes relative to head
		drawEyes(canvas, paint2);
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param paint
	 */
	private void drawEyes(Canvas canvas, Paint paint) {
		
		float eye1_OffCenterX = (this.headWidth * 0.25f);
		float eye2_OffCenterX = -eye1_OffCenterX;
		
		float eyeOffCenterY = (this.headHeight * 0.25f);
		
		canvas.save();
		
		canvas.translate(0, eyeOffCenterY);
		
		canvas.save();
		canvas.translate(eye1_OffCenterX, 0);
		canvas.drawCircle(0, 0, this.eyeRadius, paint);
		canvas.restore();
		
		canvas.save();
		canvas.translate(eye2_OffCenterX, 0);
		canvas.drawCircle(0, 0, this.eyeRadius, paint);
		canvas.restore();
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param paint
	 */
	private void drawAntena(Canvas canvas, Paint paint) {
		
		Paint androidPaint3 = new Paint(paint);
		androidPaint3.setStrokeWidth((int) (this.bodyWidth * 0.05));
		androidPaint3.setStyle(Paint.Style.STROKE);
		
		int antenaStart = (int) (this.bodyWidth * 0.2);
		int antenaLength = (int) (this.bodyWidth * 0.4);
		
		float antena_OffCenterY = (this.headHeight * 0.125f);
		
		canvas.save();
		
		canvas.translate(0, antena_OffCenterY);
		
		canvas.drawLine(antenaStart, 0, antenaLength, antenaLength, androidPaint3);
		canvas.drawLine(-antenaStart, 0, -antenaLength, antenaLength, androidPaint3);
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param width
	 * @param height
	 * @param paint
	 */
	private void drawBody(Canvas canvas, Paint paint) {
		
		float centerX = -(this.bodyWidth * 0.5f);
		float centerY = -(this.bodyHeight * 0.5f);
		
		Rect rect = new Rect(0, 0, this.bodyWidth, (int) (this.bodyHeight * 0.75f));
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(0, (this.bodyHeight * 0.25f));
		canvas.drawRect(rect, paint);
		
		RectF baseRect = new RectF(0, 0, this.bodyWidth, this.bodyHeight * 0.5f);
		
		canvas.translate(0, -(this.bodyHeight * 0.25f));
		canvas.drawRoundRect(baseRect, this.rounding, this.rounding, paint);
		
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param width
	 * @param height
	 * @param paint
	 */
	private void drawArms(Canvas canvas, Paint paint) {
		
		float centerX = -(this.armWidth * 0.5f);
		float centerY = -(this.armHeight * 0.5f);
		
		float arm1_OffCenterX = (this.bodyWidth * 0.65f);
		float arm2_OffCenterX = -arm1_OffCenterX;
		
		float offCenterY = this.bodyHeight * 0.125f;
		
		Rect rect = new Rect(0, 0, this.armWidth, this.armHeight);
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(arm1_OffCenterX, offCenterY + this.leftArmOffset);
		canvas.drawRoundRect(new RectF(rect), this.rounding, this.rounding, paint);
		canvas.restore();
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(arm2_OffCenterX, offCenterY);
		canvas.drawRoundRect(new RectF(rect), this.rounding, this.rounding, paint);
		canvas.restore();
	}
	
	/**
	 * 
	 * @param canvas
	 * @param width
	 * @param height
	 * @param paint
	 */
	private void drawLegs(Canvas canvas, Paint paint) {
		
		float centerX = -(this.legWidth * 0.5f);
		float centerY = -(this.legHeight * 0.5f);
		
		float leg1_OffCenterX = (this.bodyWidth * 0.25f);
		float leg2_OffCenterX = -leg1_OffCenterX;
		
		float leg_OffCenterY = -(this.bodyHeight * 0.65f);
		
		Rect rect = new Rect(0, 0, this.legWidth, this.legHeight);
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(leg1_OffCenterX, leg_OffCenterY + this.rightLegOffset);
		canvas.drawRoundRect(new RectF(rect), this.rounding, this.rounding, paint);
		canvas.restore();
		
		canvas.save();
		canvas.translate(centerX, centerY);
		canvas.translate(leg2_OffCenterX, leg_OffCenterY + this.leftLegOffset);
		canvas.drawRoundRect(new RectF(rect), this.rounding, this.rounding, paint);
		canvas.restore();
	}

}
